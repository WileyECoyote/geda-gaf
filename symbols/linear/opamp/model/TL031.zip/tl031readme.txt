tl031.101	(10V)Single, Low Power, JFET-Input	1	TL031 Operational Amplifier "Macromodel" Subcircuit
tl031.301	(30V)Single, Low Power, JFET-Input	1	TL031 Operational Amplifier "Macromodel" Subcircuit
