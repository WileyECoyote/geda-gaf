tle2064.101	(10V)Quad, Low Power, JFET-Input - Level 1 Model	1	TLE2064 Operational Amplifier "Macromodel" Subcircuit
tle2064.301	(30V)Quad, Low Power, JFET-Input - Level 1 Model	1	TLE2064 Operational Amplifier "Macromodel" Subcircuit
tle2064.401	(40V)Quad, Low Power, JFET-Input - Level 1 Model	1	TLE2064 Operational Amplifier "Macromodel" Subcircuit
tle2064.102	(10V)Quad, Low Power, JFET-Input - Level 2 Model	2	TLE2064 Operational Amplifier "Macromodel" Subcircuit
tle2064.302	(30V)Quad, Low Power, JFET-Input - Level 2 Model	2	TLE2064 Operational Amplifier "Macromodel" Subcircuit
tle2064.402	(40V)Quad, Low Power, JFET-Input - Level 2 Model	2	TLE2064 Operational Amplifier "Macromodel" Subcircuit
