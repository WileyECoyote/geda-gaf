tle2062.101	(10V)Dual, Low Power, JFET-Input - Level 1 Model	1	TLE2062 Operational Amplifier "Macromodel" Subcircuit
tle2062.301	(30V)Dual, Low Power, JFET-Input - Level 1 Model	1	TLE2062 Operational Amplifier "Macromodel" Subcircuit
tle2062.401	(40V)Dual, Low Power, JFET-Input - Level 1 Model	1	TLE2062 Operational Amplifier "Macromodel" Subcircuit
tle2062.102	(10V)Dual, Low Power, JFET-Input - Level 2 Model	2	TLE2062 Operational Amplifier "Macromodel" Subcircuit
tle2062.302	(30V)Dual, Low Power, JFET-Input - Level 2 Model	2	TLE2062 Operational Amplifier "Macromodel" Subcircuit
tle2062.402	(40V)Dual, Low Power, JFET-Input - Level 2 Model	2	TLE2062 Operational Amplifier "Macromodel" Subcircuit
