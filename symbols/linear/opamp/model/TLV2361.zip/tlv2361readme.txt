tlv2361.3_1	(3V)Single, Low Voltage - Level 1 Model	1	TLV2361 Operational Amplifier "Macromodel" Subcircuit
tlv2361.5_1	(5V)Single, Low Voltage - Level 1 Model	1	TLV2361 Operational Amplifier "Macromodel" Subcircuit
tlv2361.3_2	(3V)Single, Low Voltage - Level 2 Model	2	TLV2361 Operational Amplifier "Macromodel" Subcircuit
