tle2027.301	(30V)Single, Low Noise, Precision - Level 1 Model	1	TLE2027 Operational Amplifier "Macromodel" Subcircuit
tle2027.302	(30V)Single, Low Noise, Precision - Level 2 Model	2	TLE2027 Operational Amplifier "Macromodel" Subcircuit
