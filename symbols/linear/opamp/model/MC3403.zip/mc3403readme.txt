mc3403.5_1	(5V)Quad, General Purpose	1	MC3403 Operational Amplifier "Macromodel" Subcircuit
mc3403.301	(30V)Quad, General Purpose	1	MC3403 Operational Amplifier "Macromodel" Subcircuit
