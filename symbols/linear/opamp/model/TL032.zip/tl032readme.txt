tl032.101	(10V)Dual, Low Power, JFET-Input	1	TL032 Operational Amplifier "Macromodel" Subcircuit
tl032.301	(30V)Dual, Low Power, JFET-Input	1	TL032 Operational Amplifier "Macromodel" Subcircuit
