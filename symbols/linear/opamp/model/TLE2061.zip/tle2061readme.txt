tle2061.101	(10V)Single, Low Power JFET-Input - Level 1 Model	1	TLE2061 Operational Amplifier "Macromodel" Subcircuit
tle2061.301	(30V)Single, Low Power JFET-Input - Level 1 Model	1	TLE2061 Operational Amplifier "Macromodel" Subcircuit
tle2061.401	(40V)Single, Low Power JFET-Input - Level 1 Model	1	TLE2061 Operational Amplifier "Macromodel" Subcircuit
tle2061.102	(10V)Single, Low Power JFET-Input - Level 2 Model	2	TLE2061 Operational Amplifier "Macromodel" Subcircuit
tle2061.302	(30V)Single, Low Power JFET-Input - Level 2 Model	2	TLE2061 Operational Amplifier "Macromodel" Subcircuit
tle2061.402	(40V)Single, Low Power JFET-Input - Level 2 Model	2	TLE2061 Operational Amplifier "Macromodel" Subcircuit
