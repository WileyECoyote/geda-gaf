tlv2362.3_1	(3V)Dual, Low Voltage - Level 1 Model	1	TLV2362 Operational Amplifier "Macromodel" Subcircuit
tlv2362.5_1	(5V)Dual, Low Voltage - Level 1 Model	1	TLV2362 Operational Amplifier "Macromodel" Subcircuit
tlv2362.3_2	(3V)Dual, Low Voltage - Level 2 Model	2	TLV2362 Operational Amplifier "Macromodel" Subcircuit
