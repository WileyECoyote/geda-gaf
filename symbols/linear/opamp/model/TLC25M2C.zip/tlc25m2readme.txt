tlc25m2c.1_1	(1V)Dual, Low Voltage, CMOS - Level 1 Model	1	TLC25M2C Operational Amplifier "Macromodel" Subcircuit
tlc25m2c.101	(10V)Dual, Low Voltage, CMOS - Level 1 Model	1	TLC25M2C Operational Amplifier "Macromodel" Subcircuit
tlc25m2c.1_2	(1V)Dual, Low Voltage, CMOS - Level 2 Model	2	TLC25M2C Operational Amplifier "Macromodel" Subcircuit
tlc25m2c.102	(10V)Dual, Low Voltage, CMOS - Level 2 Model	2	TLC25M2C Operational Amplifier "Macromodel" Subcircuit
