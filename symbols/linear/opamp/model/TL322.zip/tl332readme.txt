tl322.5_1	(5V)Dual	1	TL322 Operational Amplifier "Macromodel" Subcircuit
tl322.301	(30V)Dual	1	TL322 Operational Amplifier "Macromodel" Subcircuit
