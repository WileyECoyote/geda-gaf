tl034.101	(10V)Quad, Low Power, JFET-Input	1	TL034 Operational Amplifier "Macromodel" Subcircuit
tl034.301	(30V)Quad, Low Power, JFET-Input	1	TL034 Operational Amplifier "Macromodel" Subcircuit
