tlc274.5_1	(5V)Quad, General Purpose, CMOS - Level 1 Model	1	TLC274 Operational Amplifier "Macromodel" Subcircuit
tlc274.101	(10V)Quad, General Purpose, CMOS - Level 1 Model	1	TLC274 Operational Amplifier "Macromodel" Subcircuit
tlc274.5_2	(5V)Quad, General Purpose, CMOS - Level 2 Model	2	TLC274 Operational Amplifier "Macromodel" Subcircuit
tlc274.102	(10V)Quad, General Purpose, CMOS - Level 2 Model	2	TLC274 Operational Amplifier "Macromodel" Subcircuit
