tlc2264.5_1	(5V)Quad, Low Noise, Micro Power, CMOS - Level 1 Model	1	TLC2264 Operational Amplifier "Macromodel" Subcircuit
tlc2264.101	(10V)Quad, Low Noise, Micro Power, CMOS - Level 1 Model	1	TLC2264 Operational Amplifier "Macromodel" Subcircuit
tlc2264.5_2	(5V)Quad, Low Noise, Micro Power, CMOS - Level 2 Model	2	TLC2264 Operational Amplifier "Macromodel" Subcircuit
tlc2264.102	(10V)Quad, Low Noise, Micro Power, CMOS - Level 2 Model	2	TLC2264 Operational Amplifier "Macromodel" Subcircuit
