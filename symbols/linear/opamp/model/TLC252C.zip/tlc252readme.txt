tlc252c.1_1	(1V)Dual, Low Voltage, CMOS - Level 1 Model	1	TLC252C Operational Amplifier "Macromodel" Subcircuit
tlc252c.101	(10V)Dual, Low Voltage, CMOS - Level 1 Model	1	TLC252C Operational Amplifier "Macromodel" Subcircuit
tlc252c.1_2	(1V)Dual, Low Voltage, CMOS - Level 2 Model	2	TLC252C Operational Amplifier "Macromodel" Subcircuit
tlc252c.102	(10V)Dual, Low Voltage, CMOS - Level 2 Model	2	TLC252C Operational Amplifier "Macromodel" Subcircuit
