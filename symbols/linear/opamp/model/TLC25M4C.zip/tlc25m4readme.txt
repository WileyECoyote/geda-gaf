tlc25m4c.1_1	(1V)Quad, Low Voltage, CMOS - Level 1 Model	1	TLC25M4C Operational Amplifier "Macromodel" Subcircuit
tlc25m4c.101	(10V)Quad, Low Voltage, CMOS - Level 1 Model	1	TLC25M4C Operational Amplifier "Macromodel" Subcircuit
tlc25m4c.1_2	(1V)Quad, Low Voltage, CMOS - Level 2 Model	2	TLC25M4C Operational Amplifier "Macromodel" Subcircuit
tlc25m4c.102	(10V)Quad, Low Voltage, CMOS - Level 2 Model	2	TLC25M4C Operational Amplifier "Macromodel" Subcircuit
