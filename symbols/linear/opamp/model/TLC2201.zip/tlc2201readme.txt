tlc2201.5_1	(5V)Single, Low Noise, CMOS - Level 1 Model	1	TLC2201 Operational Amplifier "Macromodel" Subcircuit
tlc2201.101	(10V)Single, Low Noise, CMOS - Level 1 Model	1	TLC2201 Operational Amplifier "Macromodel" Subcircuit
tlc2201.5_2	(5V)Single, Low Noise, CMOS - Level 2 Model	2	TLC2201 Operational Amplifier "Macromodel" Subcircuit
tlc2201.102	(10V)Single, Low Noise, CMOS - Level 2 Model	2	TLC2201 Operational Amplifier "Macromodel" Subcircuit
