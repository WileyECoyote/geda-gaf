tl052.101	(10V)Dual, High-Speed, JFET-Input	1	TL052 Operational Amplifier "Macromodel" Subcircuit
tl052.301	(30V)Dual, High-Speed, JFET-Input		TL052 Operational Amplifier "Macromodel" Subcircuit
