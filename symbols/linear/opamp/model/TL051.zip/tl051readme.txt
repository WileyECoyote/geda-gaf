tl051.101	(10V)Single, High Speed, JFET-Input	1	TL051 Operational Amplifier "Macromodel" Subcircuit
tl051.301	(30V)Single, High Speed, JFET-Input	1	TL051 Operational Amplifier "Macromodel" Subcircuit
