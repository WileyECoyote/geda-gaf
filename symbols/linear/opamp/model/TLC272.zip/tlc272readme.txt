tlc272.5_1	(5V)Dual, General Purpose, CMOS - Level 1 Model	1	TLC272 Operational Amplifier "Macromodel" Subcircuit
tlc272.101	(10V)Dual, General Purpose, CMOS - Level 1 Model	1	TLC272 Operational Amplifier "Macromodel" Subcircuit
tlc272.5_2	(5V)Dual, General Purpose, CMOS - Level 2 Model	2	TLC272 Operational Amplifier "Macromodel" Subcircuit
tlc272.102	(10V)Dual, General Purpose, CMOS - Level 2 Model	2	TLC272 Operational Amplifier "Macromodel" Subcircuit
