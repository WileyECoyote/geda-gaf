tl054.101	(10V)Quad, High-Speed, JFET-Input	1	TL054 Operational Amplifier "Macromodel" Subcircuit
tl054.301	(30V)Quad, High-Speed, JFET-Input	1	TL054 Operational Amplifier "Macromodel" Subcircuit
