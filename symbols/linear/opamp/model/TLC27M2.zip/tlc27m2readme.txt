tlc27m2.5_1	(5V)Dual, General Purpose, CMOS - Level 1 Model	1	TLC27M2 Operational Amplifier "Macromodel" Subcircuit
tlc27m2.101	(10V)Dual, General Purpose, CMOS - Level 1 Model	1	TLC27M2 Operational Amplifier "Macromodel" Subcircuit
tlc27m2.5_2	(5V)Dual, General Purpose, CMOS - Level 2 Model	2	TLC27M2 Operational Amplifier "Macromodel" Subcircuit
tlc27m2.102	(10V)Dual, General Purpose, CMOS - Level 2 Model	2	TLC27M2 Operational Amplifier "Macromodel" Subcircuit
