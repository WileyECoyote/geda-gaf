tle2022.5_1	(5V)Dual, Precision, Low Power - Level 1 Model	1	TLE2022 Operational Amplifier "Macromodel" Subcircuit
tle2022.301	(30V)Dual, Precision, Low Power - Level 1 Model	1	TLE2022 Operational Amplifier "Macromodel" Subcircuit
tle2022.5_2	(5V)Dual, Precision, Low Power - Level 2 Model	2	TLE2022 Operational Amplifier "Macromodel" Subcircuit
tle2022.302	(30V)Dual, Precision, Low Power - Level 2 Model	2	TLE2022 Operational Amplifier "Macromodel" Subcircuit
