tle2161.101	(10V)Single, Decompensated, JFET-Input - Level 1 Model	1	TLE2161 Operational Amplifier "Macromodel" Subcircuit
tle2161.301	(30V)Single, Decompensated, JFET-Input - Level 1 Model	1	TLE2161 Operational Amplifier "Macromodel" Subcircuit
tle2161.401	(40V)Single, Decompensated, JFET-Input - Level 1 Model	1	TLE2161 Operational Amplifier "Macromodel" Subcircuit
tle2161.102	(10V)Single, Decompensated, JFET-Input - Level 2 Model	2	TLE2161 Operational Amplifier "Macromodel" Subcircuit
tle2161.302	(30V)Single, Decompensated, JFET-Input - Level 2 Model	2	TLE2161 Operational Amplifier "Macromodel" Subcircuit
tle2161.402	(40V)Single, Decompensated, JFET-Input - Level 2 Model	2	TLE2161 Operational Amplifier "Macromodel" Subcircuit
