tlc279.5_1	(5V)Quad, Precision, CMOS - Level 1 Model	1	TLC279 Operational Amplifier "Macromodel" Subcircuit
tlc279.101	(10V)Quad, Precision, CMOS - Level 1 Model	1	TLC279 Operational Amplifier "Macromodel" Subcircuit
tlc279.5_2	(5V)Quad, Precision, CMOS - Level 2 Model	2	TLC279 Operational Amplifier "Macromodel" Subcircuit
tlc279.102	(10V)Quad, Precision, CMOS - Level 2 Model	2	TLC279 Operational Amplifier "Macromodel" Subcircuit
