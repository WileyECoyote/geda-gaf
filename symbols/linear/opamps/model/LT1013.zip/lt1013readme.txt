lt1013.5_1	(5V)Dual, Low Power, Precision, Low Noise	1	LT1013 Operational Amplifier "Macromodel" Subcircuit
lt1013.301	(30V)Dual, Low Power, Precision, Low Noise	1	LT1013 Operational Amplifier "Macromodel" Subcircuit

